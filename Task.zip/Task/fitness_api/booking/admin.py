from django.contrib import admin
from .models import FitnessClass, Booking
# Register your models here.

admin.site.register(FitnessClass)
admin.site.register(Booking)